import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-javahome-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class JavahomeLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
