import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentcomplete-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class StudentcompleteLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
