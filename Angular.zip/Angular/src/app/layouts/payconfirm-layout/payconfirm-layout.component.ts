import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payconfirm-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class PayconfirmLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
