import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup-layout',
  template: `
  <router-outlet></router-outlet>
  `,
  styles: []
})
export class SignupLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
