import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorprofile-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class MentorprofileLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
