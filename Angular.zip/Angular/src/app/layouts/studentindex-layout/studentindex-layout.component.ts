import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentindex-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class StudentindexLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
