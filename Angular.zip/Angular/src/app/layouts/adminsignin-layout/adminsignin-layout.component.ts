import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminsignin-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class AdminsigninLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
