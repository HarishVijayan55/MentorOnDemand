import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentcurrent-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class StudentcurrentLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
