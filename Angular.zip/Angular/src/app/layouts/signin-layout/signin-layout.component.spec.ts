import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SigninLayoutComponent } from './signin-layout.component';

describe('SigninLayoutComponent', () => {
  let component: SigninLayoutComponent;
  let fixture: ComponentFixture<SigninLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SigninLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SigninLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
