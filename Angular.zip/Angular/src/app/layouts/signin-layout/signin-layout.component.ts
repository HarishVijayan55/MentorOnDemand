import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signin-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class SigninLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
