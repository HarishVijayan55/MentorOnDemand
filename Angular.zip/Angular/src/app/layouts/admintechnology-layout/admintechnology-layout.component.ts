import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admintechnology-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class AdmintechnologyLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
