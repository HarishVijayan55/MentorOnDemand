import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageaccount-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class ManageaccountLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
