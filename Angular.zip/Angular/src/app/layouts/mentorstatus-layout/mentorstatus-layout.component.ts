import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorstatus-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class MentorstatusLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
