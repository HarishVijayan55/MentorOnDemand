import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hibernatehome-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class HibernatehomeLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
