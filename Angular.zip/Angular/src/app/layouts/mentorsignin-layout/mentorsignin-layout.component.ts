import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorsignin-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class MentorsigninLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
