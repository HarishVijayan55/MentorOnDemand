import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-springhome-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class SpringhomeLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
