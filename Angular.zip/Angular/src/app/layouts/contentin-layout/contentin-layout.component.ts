import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contentin-layout',
  template: `
  <app-navbar></app-navbar>
  `,
  styles: []
})
export class ContentinLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
