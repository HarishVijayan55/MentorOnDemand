import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentoredit-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class MentoreditLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
