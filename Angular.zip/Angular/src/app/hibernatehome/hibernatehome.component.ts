import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hibernatehome',
  templateUrl: './hibernatehome.component.html',
  styleUrls: ['./hibernatehome.component.scss']
})
export class HibernatehomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
