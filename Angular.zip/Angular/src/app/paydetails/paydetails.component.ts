import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paydetails',
  templateUrl: './paydetails.component.html',
  styleUrls: ['./paydetails.component.scss']
})
export class PaydetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
