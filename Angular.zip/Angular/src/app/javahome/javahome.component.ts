import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-javahome',
  templateUrl: './javahome.component.html',
  styleUrls: ['./javahome.component.scss']
})
export class JavahomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
