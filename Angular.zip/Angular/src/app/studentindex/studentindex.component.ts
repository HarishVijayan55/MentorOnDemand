import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentindex',
  templateUrl: './studentindex.component.html',
  styleUrls: ['./studentindex.component.scss']
})
export class StudentindexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
