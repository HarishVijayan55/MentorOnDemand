import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorstatus',
  templateUrl: './mentorstatus.component.html',
  styleUrls: ['./mentorstatus.component.scss']
})
export class MentorstatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
