import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentcurrent',
  templateUrl: './studentcurrent.component.html',
  styleUrls: ['./studentcurrent.component.scss']
})
export class StudentcurrentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
