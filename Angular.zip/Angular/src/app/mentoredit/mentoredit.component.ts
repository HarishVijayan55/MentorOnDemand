import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentoredit',
  templateUrl: './mentoredit.component.html',
  styleUrls: ['./mentoredit.component.scss']
})
export class MentoreditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
