export class User{
    userName:String;
    password:String;
}
export class Mentor{
    mentorName:String;
    password:String;
    knownCourse:String;
    experience:String;
    
}
export class Admin{
    email:String;
    password:String;
}
export class Course{
    courseName:String;
}

export class Block{
    username:String;

}