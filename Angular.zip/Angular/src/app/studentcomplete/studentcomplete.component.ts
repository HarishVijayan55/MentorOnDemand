import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentcomplete',
  templateUrl: './studentcomplete.component.html',
  styleUrls: ['./studentcomplete.component.scss']
})
export class StudentcompleteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
