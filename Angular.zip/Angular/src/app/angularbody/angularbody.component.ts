import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angularbody',
  templateUrl: './angularbody.component.html',
  styleUrls: ['./angularbody.component.scss']
})
export class AngularbodyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
