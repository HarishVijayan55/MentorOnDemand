import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-springhome',
  templateUrl: './springhome.component.html',
  styleUrls: ['./springhome.component.scss']
})
export class SpringhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
