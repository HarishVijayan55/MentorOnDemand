import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payconfirm',
  templateUrl: './payconfirm.component.html',
  styleUrls: ['./payconfirm.component.scss']
})
export class PayconfirmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
